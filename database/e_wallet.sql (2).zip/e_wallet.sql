-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2023 at 06:29 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e_wallet`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `ACCOUNT_NUMBER` int(11) NOT NULL,
  `User_Id` int(11) DEFAULT NULL,
  `wallet_id` int(11) DEFAULT NULL,
  `Balance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `User_Id` int(11) NOT NULL,
  `Fname` varchar(250) NOT NULL,
  `Lname` varchar(250) DEFAULT NULL,
  `PhoneNO` int(10) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`User_Id`, `Fname`, `Lname`, `PhoneNO`, `Email`, `Username`, `Password`) VALUES
(1, 'king', 'isiaheli', 785361798, 'isiaheli12@gmail.com', '', ''),
(2, 'Mourice', 'Kwizera', 784735244, 'kwizera@gmail.com', 'admin', 'admin'),
(3, 'rwqerwqerw', 'werwerwer', 121231212, 'werwerwe', 'werwerwer', 'werwerwer'),
(4, 'rwqerwqerw', 'werwerwer', 121231212, 'werwerwe', 'werwerwer', 'werwerwer'),
(5, 'rwqerwqerw', 'werwerwer', 121231212, 'werwerwe', 'werwerwer', 'werwerwer'),
(6, 'MUKIZA', 'Janvveir', 123454566, 'fasfsafsa@gmaill,. om', 'qwerrt', '123'),
(7, 'Lambert', 'Habyarimana', 1231134141, 'lambert@gmail.com', 'HabLamb', '12345'),
(8, 'ISIRARELI', 'King', 782222223, 'isiraheli121@gmail.com', 'Isiraheliking', '12345'),
(9, 'MUJAWIMANA`', 'Delphine', 781234567, 'muja123@gmail.com', 'Delphine', '00000');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `type` varchar(250) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transaction_id`, `timestamp`, `type`, `amount`, `description`) VALUES
(40, '2023-01-19 07:30:58', 'American Dollar (USD)', 100, 'Deposited'),
(41, '2023-01-19 07:31:09', 'American Dollar (USD)', 50, 'Withdrawn'),
(42, '2023-01-19 07:31:30', 'American Dollar (USD)', 20, 'Transfered');

-- --------------------------------------------------------

--
-- Table structure for table `wallet`
--

CREATE TABLE `wallet` (
  `WALLET_id` int(11) NOT NULL,
  `User_id` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wallet`
--

INSERT INTO `wallet` (`WALLET_id`, `User_id`, `amount`) VALUES
(6, 1, 830);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`ACCOUNT_NUMBER`),
  ADD KEY `fk_account_number` (`wallet_id`),
  ADD KEY `fk_accounts_number` (`User_Id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`User_Id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `wallet`
--
ALTER TABLE `wallet`
  ADD PRIMARY KEY (`WALLET_id`),
  ADD KEY `fk_wallet_id` (`User_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `ACCOUNT_NUMBER` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `User_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `wallet`
--
ALTER TABLE `wallet`
  MODIFY `WALLET_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `fk_account_number` FOREIGN KEY (`wallet_id`) REFERENCES `wallet` (`WALLET_id`),
  ADD CONSTRAINT `fk_accounts_number` FOREIGN KEY (`User_Id`) REFERENCES `customer` (`User_Id`);

--
-- Constraints for table `wallet`
--
ALTER TABLE `wallet`
  ADD CONSTRAINT `fk_wallet_id` FOREIGN KEY (`User_id`) REFERENCES `customer` (`User_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
